import * as i0 from '@angular/core';
import { Component, ViewEncapsulation, ChangeDetectionStrategy, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

class LinkThreePreviewViewComponent {
    constructor() {
    }
    ngOnInit() {
    }
}
LinkThreePreviewViewComponent.ɵfac = function LinkThreePreviewViewComponent_Factory(t) { return new (t || LinkThreePreviewViewComponent)(); };
LinkThreePreviewViewComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: LinkThreePreviewViewComponent, selectors: [["link-three-preview-view"]], decls: 1, vars: 0, template: function LinkThreePreviewViewComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵelement(0, "article");
    } }, encapsulation: 2, changeDetection: 0 });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(LinkThreePreviewViewComponent, [{
        type: Component,
        args: [{
                selector: 'link-three-preview-view',
                templateUrl: 'link-three-preview-view.component.html',
                encapsulation: ViewEncapsulation.None,
                changeDetection: ChangeDetectionStrategy.OnPush
            }]
    }], function () { return []; }, null); })();

class LinkThreePreviewViewModule {
}
LinkThreePreviewViewModule.ɵfac = function LinkThreePreviewViewModule_Factory(t) { return new (t || LinkThreePreviewViewModule)(); };
LinkThreePreviewViewModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: LinkThreePreviewViewModule });
LinkThreePreviewViewModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [[
            CommonModule
        ]] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(LinkThreePreviewViewModule, [{
        type: NgModule,
        args: [{
                imports: [
                    CommonModule
                ],
                declarations: [
                    LinkThreePreviewViewComponent
                ],
                exports: [
                    LinkThreePreviewViewComponent
                ]
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(LinkThreePreviewViewModule, { declarations: [LinkThreePreviewViewComponent], imports: [CommonModule], exports: [LinkThreePreviewViewComponent] }); })();

/**
 * @author milton.romero
 */

/**
 * @author milton.romero
 */

/**
 * @author milton.romero
 */

/**
 * @author milton.romero
 */

/**
 * @author milton.romero
 */

/**
 * Generated bundle index. Do not edit.
 */

export { LinkThreePreviewViewComponent, LinkThreePreviewViewModule };
//# sourceMappingURL=link-three-service-link-three-view.js.map

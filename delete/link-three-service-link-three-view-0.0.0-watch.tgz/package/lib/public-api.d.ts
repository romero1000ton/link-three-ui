/**
 * @author milton.romero
 */
export * from './components/index';
//# sourceMappingURL=public-api.d.ts.map
import { OnInit } from '@angular/core';
import * as i0 from "@angular/core";
export declare class LinkThreePreviewViewComponent implements OnInit {
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LinkThreePreviewViewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LinkThreePreviewViewComponent, "link-three-preview-view", never, {}, {}, never, never>;
}
//# sourceMappingURL=link-three-preview-view.component.d.ts.map
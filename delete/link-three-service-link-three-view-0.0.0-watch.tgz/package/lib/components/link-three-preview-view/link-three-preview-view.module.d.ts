import * as i0 from "@angular/core";
import * as i1 from "./link-three-preview-view.component";
import * as i2 from "@angular/common";
export declare class LinkThreePreviewViewModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<LinkThreePreviewViewModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<LinkThreePreviewViewModule, [typeof i1.LinkThreePreviewViewComponent], [typeof i2.CommonModule], [typeof i1.LinkThreePreviewViewComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<LinkThreePreviewViewModule>;
}
//# sourceMappingURL=link-three-preview-view.module.d.ts.map